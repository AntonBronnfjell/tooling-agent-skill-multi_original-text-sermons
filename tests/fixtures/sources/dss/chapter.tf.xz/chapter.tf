@node
@acronym=dss
@convertedBy=Jarod Jacobs, Martijn Naaijer and Dirk Roorda
@createdBy=Martin G. Abegg, Jr., James E. Bowley, and Edward M. Cook
@createdDate=2015
@dateWritten=2020-07-14T14:51:30Z
@description=label of the chapter in which the word occurs
@license=Creative Commons Attribution-NonCommercial 4.0 International License
@licenseUrl=http://creativecommons.org/licenses/by-nc/4.0/
@source=Martin Abegg's data files, personal communication
@valueType=str
@writtenBy=Text-Fabric
@writtenBy=Text-Fabric
@dateWritten=2020-12-29T15:01:56Z

1914489	53
1914490	53
1914491	53
1914492	53
1914493	53
1914494	53
1914495	53
1914496	53
1914497	53
1914498	53
1914499	53
1914500	53
1914501	53
1914502	53
1914503	53
1914504	53
1914505	53
1914506	53
1914507	53
1914508	53
