@node
@acronym=dss
@convertedBy=Jarod Jacobs, Martijn Naaijer and Dirk Roorda
@createdBy=Martin G. Abegg, Jr., James E. Bowley, and Edward M. Cook
@createdDate=2015
@dateWritten=2020-07-14T14:51:31Z
@description=correction made by an ancient or modern editor
@license=Creative Commons Attribution-NonCommercial 4.0 International License
@licenseUrl=http://creativecommons.org/licenses/by-nc/4.0/
@source=Martin Abegg's data files, personal communication
@valueType=int
@values=1 = modern, 2 = ancient, 3 = ancient supralinear
@writtenBy=Text-Fabric
@writtenBy=Text-Fabric
@dateWritten=2020-12-29T15:01:57Z

847928	3
