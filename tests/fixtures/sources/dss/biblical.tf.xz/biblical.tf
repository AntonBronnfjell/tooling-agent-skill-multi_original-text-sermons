@node
@acronym=dss
@applies=scroll fragment line cluster word
@convertedBy=Jarod Jacobs, Martijn Naaijer and Dirk Roorda
@createdBy=Martin G. Abegg, Jr., James E. Bowley, and Edward M. Cook
@createdDate=2015
@dateWritten=2020-07-14T14:51:30Z
@description=whether we are in biblical material or not
@license=Creative Commons Attribution-NonCommercial 4.0 International License
@licenseUrl=http://creativecommons.org/licenses/by-nc/4.0/
@remark=for lines it means that the material is taken from the bib source while there is also material for this line in the nonbib source. But the nonbib material is either identical or virtually absent, in which case the bib material is a reconstruction and marked as such.
@source=Martin Abegg's data files, personal communication
@valueType=int
@values=1=biblical, 2=biblical but also with nonbiblical material
@writtenBy=Text-Fabric
@writtenBy=Text-Fabric
@dateWritten=2020-12-29T15:01:56Z

1540463	1
1591380	1
1591381	1
1606613	1
1914489	1
1914490	1
1914491	1
1914492	1
1914493	1
1914494	1
1914495	1
1914496	1
1914497	1
1914498	1
1914499	1
1914500	1
1914501	1
1914502	1
1914503	1
1914504	1
1914505	1
1914506	1
1914507	1
1914508	1
