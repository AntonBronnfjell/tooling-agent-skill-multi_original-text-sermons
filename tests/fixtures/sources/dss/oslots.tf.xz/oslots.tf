@edge
@acronym=dss
@convertedBy=Jarod Jacobs, Martijn Naaijer and Dirk Roorda
@createdBy=Martin G. Abegg, Jr., James E. Bowley, and Edward M. Cook
@createdDate=2015
@dateWritten=2020-07-14T14:51:51Z
@description=Dead Sea Scrolls: biblical and non-biblical scrolls
@license=Creative Commons Attribution-NonCommercial 4.0 International License
@licenseUrl=http://creativecommons.org/licenses/by-nc/4.0/
@source=Martin Abegg's data files, personal communication
@valueType=str
@writtenBy=Text-Fabric
@writtenBy=Text-Fabric
@dateWritten=2020-12-29T15:02:17Z

1540463	847206-848490
1591380	848031-848076
1591381	848077-848126
1606613	784925-863030
1914489	848042
1914490	848043-848045
1914491	848046-848051
1914492	848052-848055
1914493	848056-848058
1914494	848059
1914495	848060-848063
1914496	848064
1914497	848065
1914498	848066-848070
1914499	848071-848075
1914500	848077-848080
1914501	848081-848085
1914502	848086
1914503	848087-848090
1914504	848091
1914505	848092-848099
1914506	848100-848103
1914507	848104-848108
1914508	848109-848110
