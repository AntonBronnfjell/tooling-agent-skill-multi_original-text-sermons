@node
@acronym=dss
@convertedBy=Jarod Jacobs, Martijn Naaijer and Dirk Roorda
@createdBy=Martin G. Abegg, Jr., James E. Bowley, and Edward M. Cook
@createdDate=2015
@dateWritten=2020-07-14T14:51:34Z
@description=representation (Unicode) of a word or sign
@license=Creative Commons Attribution-NonCommercial 4.0 International License
@licenseUrl=http://creativecommons.org/licenses/by-nc/4.0/
@source=Martin Abegg's data files, personal communication
@valueType=str
@writtenBy=Text-Fabric
@writtenBy=Text-Fabric
@dateWritten=2020-12-29T15:02:00Z

848042	מ
848043	ע
848044	מ
848045	ל
848046	נ
848047	פ
848048	ש
848049	׳
848050	ו
848051	ה
848052	י
848053	ר
848054	א
848055	ה
848056	א
848057	ו
848058	ר
848059	ו
848060	י
848061	ש
848062	ב
848063	ע
848064	ו
848065	ב
848066	ד
848067	ע
848068	ת
848069	׳
848070	ו
848071	י
848072	צ
848073	ד
848074	י
848075	ק
848077	צ
848078	ד
848079	י
848080	ק
848081	ע
848082	ב
848083	ד
848084	׳
848085	ו
848086	ל
848087	ר
848088	ב
848089	י
848090	ם
848091	ו
848092	ע
848093	ו
848094	ו
848095	נ
848096	ו
848097	ת
848098	׳
848099	ם
848100	ה
848101	ו
848102	א
848103	ה
848104	י
848105	ס
848106	ב
848107	ו
848108	ל
848109	
848110	׃
1914489	מ
1914490	עמל
1914491	נפש׳וה
1914492	יראה
1914493	אור
1914494	ו
1914495	ישבע
1914496	ו
1914497	ב
1914498	דעת׳ו
1914499	יצדיק
1914500	צדיק
1914501	עבד׳ו
1914502	ל
1914503	רבים
1914504	ו
1914505	עוונות׳ם
1914506	הואה
1914507	יסבול
