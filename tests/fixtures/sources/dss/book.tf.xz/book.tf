@node
@acronym=dss
@convertedBy=Jarod Jacobs, Martijn Naaijer and Dirk Roorda
@createdBy=Martin G. Abegg, Jr., James E. Bowley, and Edward M. Cook
@createdDate=2015
@dateWritten=2020-07-14T14:51:30Z
@description=acronym of the book in which the word occurs
@license=Creative Commons Attribution-NonCommercial 4.0 International License
@licenseUrl=http://creativecommons.org/licenses/by-nc/4.0/
@source=Martin Abegg's data files, personal communication
@valueType=str
@writtenBy=Text-Fabric
@writtenBy=Text-Fabric
@dateWritten=2020-12-29T15:01:56Z

1914489	Is
1914490	Is
1914491	Is
1914492	Is
1914493	Is
1914494	Is
1914495	Is
1914496	Is
1914497	Is
1914498	Is
1914499	Is
1914500	Is
1914501	Is
1914502	Is
1914503	Is
1914504	Is
1914505	Is
1914506	Is
1914507	Is
1914508	Is
