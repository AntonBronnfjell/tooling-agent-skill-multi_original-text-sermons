@node
@acronym=dss
@convertedBy=Jarod Jacobs, Martijn Naaijer and Dirk Roorda
@createdBy=Martin G. Abegg, Jr., James E. Bowley, and Edward M. Cook
@createdDate=2015
@dateWritten=2020-07-14T14:51:49Z
@description=label of the verse in which the word occurs
@license=Creative Commons Attribution-NonCommercial 4.0 International License
@licenseUrl=http://creativecommons.org/licenses/by-nc/4.0/
@source=Martin Abegg's data files, personal communication
@valueType=str
@writtenBy=Text-Fabric
@writtenBy=Text-Fabric
@dateWritten=2020-12-29T15:02:15Z

1914489	11
1914490	11
1914491	11
1914492	11
1914493	11
1914494	11
1914495	11
1914496	11
1914497	11
1914498	11
1914499	11
1914500	11
1914501	11
1914502	11
1914503	11
1914504	11
1914505	11
1914506	11
1914507	11
1914508	11
