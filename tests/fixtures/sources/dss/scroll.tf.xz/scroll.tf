@node
@acronym=dss
@convertedBy=Jarod Jacobs, Martijn Naaijer and Dirk Roorda
@createdBy=Martin G. Abegg, Jr., James E. Bowley, and Edward M. Cook
@createdDate=2015
@dateWritten=2020-07-14T14:51:46Z
@description=acronym of a scroll
@license=Creative Commons Attribution-NonCommercial 4.0 International License
@licenseUrl=http://creativecommons.org/licenses/by-nc/4.0/
@source=Martin Abegg's data files, personal communication
@valueType=str
@writtenBy=Text-Fabric
@writtenBy=Text-Fabric
@dateWritten=2020-12-29T15:02:12Z

1540463	1Qisaa
1540501	1Q8
1541534	4Q56
1541606	4Q58
1591377	1Qisaa
1591378	1Qisaa
1591380	1Qisaa
1591381	1Qisaa
1592037	1Q8
1592038	1Q8
1598633	4Q56
1599029	4Q58
1599030	4Q58
1606613	1Qisaa
1606614	1Q8
1606710	4Q56
1606712	4Q58
