@node
@acronym=dss
@convertedBy=Jarod Jacobs, Martijn Naaijer and Dirk Roorda
@createdBy=Martin G. Abegg, Jr., James E. Bowley, and Edward M. Cook
@createdDate=2015
@dateWritten=2020-07-14T14:51:49Z
@description=uncertain material in various degrees: higher degree is less certain
@license=Creative Commons Attribution-NonCommercial 4.0 International License
@licenseUrl=http://creativecommons.org/licenses/by-nc/4.0/
@source=Martin Abegg's data files, personal communication
@valueType=int
@values=1 2 3 4
@writtenBy=Text-Fabric
@writtenBy=Text-Fabric
@dateWritten=2020-12-29T15:02:15Z

847928	2
880772	4
880791	4
880792	2
880796	4
880797	4
1159749	4
1174979	2
1174988	3
1174990	1
1174993	4
1175013	1
1175015	4
