@node
@acronym=dss
@convertedBy=Jarod Jacobs, Martijn Naaijer and Dirk Roorda
@createdBy=Martin G. Abegg, Jr., James E. Bowley, and Edward M. Cook
@createdDate=2015
@dateWritten=2020-07-14T14:51:40Z
@description=representation (Unicode) of a lexeme
@license=Creative Commons Attribution-NonCommercial 4.0 International License
@licenseUrl=http://creativecommons.org/licenses/by-nc/4.0/
@source=Martin Abegg's data files, personal communication
@valueType=str
@writtenBy=Text-Fabric
@writtenBy=Text-Fabric
@dateWritten=2020-12-29T15:02:06Z

1914489	מִן
1914490	עָמָל_1
1914491	נֶפֶשׁ
1914492	ראה
1914493	אֹור
1914494	וְ
1914495	שׂבע
1914496	וְ
1914497	בְּ
1914498	דַּעַת_1
1914499	צדק
1914500	צַדִּיק
1914501	עֶבֶד_1
1914502	לְ
1914503	רַב_1
1914504	וְ
1914505	עָוֹן
1914506	הוּא
1914507	סבל
