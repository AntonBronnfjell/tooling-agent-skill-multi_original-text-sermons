@node
@acronym=dss
@convertedBy=Jarod Jacobs, Martijn Naaijer and Dirk Roorda
@createdBy=Martin G. Abegg, Jr., James E. Bowley, and Edward M. Cook
@createdDate=2015
@dateWritten=2020-07-14T14:51:45Z
@description=reconstructed by a modern editor
@license=Creative Commons Attribution-NonCommercial 4.0 International License
@licenseUrl=http://creativecommons.org/licenses/by-nc/4.0/
@source=Martin Abegg's data files, personal communication
@valueType=int
@values=1
@writtenBy=Text-Fabric
@writtenBy=Text-Fabric
@dateWritten=2020-12-29T15:02:11Z

880773	1
880774	1
880775	1
880776	1
880777	1
880778	1
880779	1
880780	1
880782	1
880783	1
880784	1
880785	1
880786	1
880787	1
880788	1
880789	1
880790	1
880798	1
880799	1
1159725	1
1159726	1
1159727	1
1159728	1
1159729	1
1159730	1
1159731	1
1159732	1
1159733	1
1159734	1
1159735	1
1159736	1
1159737	1
1159738	1
1159739	1
1159740	1
1159741	1
1159742	1
1159743	1
1159744	1
1159745	1
1159750	1
1159751	1
1159752	1
1174989	1
1175016	1
1175017	1
1175018	1
1175019	1
1175020	1
1175021	1
1175022	1
1175023	1
1175024	1
1175025	1
